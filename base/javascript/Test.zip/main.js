define(["Backbone", "Plugin"],function(Backbone, Plugin){
	return Plugin.extend({
		install:function(){
			
		}
	})
})