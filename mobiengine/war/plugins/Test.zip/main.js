define(['Plugin'],function(Plugin){
	return Plugin.extend({
		title:'Test'
	})
})